void Kezd(int m, int n);
void EnLepesem(int &a, int &b);
void TeLepesed(int a, int b);
