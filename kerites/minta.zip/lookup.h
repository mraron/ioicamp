extern int Drift (long x, long y, long z);
extern long GetN();
extern void Answer (long left, long right);
