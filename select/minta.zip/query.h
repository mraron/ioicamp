extern int Size(void);
extern int Member(int i, int j);
extern void Answer(int i);


